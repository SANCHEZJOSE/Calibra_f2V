long int  readChannels(long int *);
long int  readChannel(long int);
int       adcStart(int argc, char*, char*, char *);
int       adcStop(void);
